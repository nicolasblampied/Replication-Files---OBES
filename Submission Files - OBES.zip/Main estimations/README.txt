This file explains the procedure to estimate the smooth local projections (SLP) in the terms Barnichon and Brownlees (2019) to the MP Shock of Jarocinski and Karadi (2020).
The main Matlab files to proceed with the estimations are Main_US_SLP and Main_US_QuarterlyData.
Acknowledgements: The codes were retrieved from the supplementary material of Barnichon and Brownlees (2019) and adapted to the needs of the present paper. 



In order to replicate the main results of the paper, please note:




FIGURE 4: 

In Main_US_SLP: 

1) Select load 'Business Asymmetry - LEVEL - 1990-2016.mat'.

2) Select the variables corresponding to the log level specification.

3) Select the dependent variables one at a time. Remember you can choose:

a) Mu_CD
b) Mu_CES_KVU
c) Mu_CES_KVU_OH
d) GDPG
e) Indprod (industrial production to replicate Figure B3 in the appendix)

4) Select the corresponding shock bearing in mind that:

MSExp represents the MP Tightening shock in expansions.
MSRec represents the MP Tightening shock in Recessions.
MSPos represents the MP Tightening shock without business cycle dependence.

5) Select controls. Remember to include the linear trend (TT) in this specification and to check the autocorrelation function of the shock to include its lags.

6) Run the code and get the IRFs and the 10% confidence interval one at a time.




FIGURE 5: 

In Main_US_SLP: 

1) Select load 'Business Asymmetry - DIFF - 1990-2016.mat'.

2) Select the dependent variables corresponding to the log level specification.

3) Select the dependent variables one at a time. Remember you can choose:

a) Mu_CD
b) Mu_CES_KVU
c) Mu_CES_KVU_OH
d) GDPG
e) Indprod (industrial production to replicate Figure B3 in the appendix)

4) Select the corresponding shock bearing in mind that:

MSExp represents the MP Tightening shock in expansions.
MSRec represents the MP Tightening shock in Recessions.
MSPos represents the MP Tightening shock without business cycle dependence.

5) Select controls. Remember to avoid the linear trend (TT) in this specification and to check the autocorrelation function of the shock to include its lags.

6) Run the code and get the IRFs and the 10% confidence interval one at a time.




FIGURE B1:

In Main_US_QuarterlyData:

1) Select load 'Business Asymmetry - Quarterly - 1990-2016.mat'

2) Select the corresponding shock bearing in mind that:

MSExp represents the MP Tightening shock in expansions.
MSRec represents the MP Tightening shock in Recessions.
MSPos represents the MP Tightening shock without business cycle dependence.

3) Select the dependent variables at the same time. Remember you can choose:

a) Mu_CD
b) Mu_CES_KVU
c) Mu_CES_KVU_OH

4) Select Controls.

5) Run the code and get the IRFs and the 5% and 10% confidence interval for the three variables at the same time.




FIGURE B2: 

In Main_US_SLP: 

1) Select load 'Business Asymmetry - LEVEL - 1990-2007.mat'.

2) Select the variables corresponding to the log level specification.

3) Select the dependent variables one at a time. Remember you can choose:

a) Mu_CD
b) Mu_CES_KVU
c) Mu_CES_KVU_OH
e) Indprod (industrial production to replicate Figure B3 in the appendix)

4) Select the corresponding shock bearing in mind that:

MSExp represents the MP Tightening shock in expansions.
MSRec represents the MP Tightening shock in Recessions.
MSPos represents the MP Tightening shock without business cycle dependence.

5) Select controls. Remember to include the linear trend (TT) in this specification, avoid the D_2008 dummy, and to check the autocorrelation function of the shock to include its lags.

6) Run the code and get the IRFs and the 10% confidence interval one at a time.


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

For an explanation of the files locproj.m, locproj_conf.m, and locproj_cv.m, please see Barnichon and Brownlees (2019).

